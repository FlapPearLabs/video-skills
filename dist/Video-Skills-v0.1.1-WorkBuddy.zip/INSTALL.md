Video Skills 0.1.1 · WorkBuddy安装集合

外层ZIP是分发集合，不是单个Skill安装包。解压后进入workbuddy，先上传video-setup-v0.1.1.zip；在WorkBuddy技能→添加技能→上传技能中选择这个独立ZIP。通过资源读取检查后，再逐个上传其余五个ZIP。

每个独立ZIP只有一个技能目录，内含SKILL.md和其全部运行资源；不要把六个ZIP一并当成一个Skill上传。
先让Agent真实读取project-contract.md中的局部批准继承规则，再运行本技能project_files.py --help；没有真实回执不算验收通过。完整非生成/恢复清单在video-setup的references/workbuddy-acceptance.md。

已做：元数据、引用、资源完整性、Python语法、ZIP结构的本地检查。未做：WorkBuddy客户端导入/资源实际加载、LibTV真实联调、视频生成、口型与商业交付验收。
默认关闭未批准生成；原有可用预算内的明确局部修改继承批准，但不得增加金额、调用次数或素材范围。
