---
name: video-to-tickets
display_name: 视频任务拆分
display_name_en: Video to Tickets
description: 将视频 SPEC 拆成可独立验收的素材、分镜、预演、镜头、音频、字幕、剪辑和交付任务，并声明依赖与 LibTV 节点映射计划。用于已确认视频规格后的排产、预算分解、跨会话执行准备或局部修改任务拆分。
description_zh: 将视频 SPEC 拆成可独立验收的素材、分镜、预演、镜头、音频、字幕、剪辑和交付任务，并声明依赖与 LibTV 节点映射计划。用于已确认视频规格后的排产、预算分解、跨会话执行准备或局部修改任务拆分。
description_en: Split a video specification into dependency-aware production tickets.
version: 0.1.1
author: 宋仕尧
---

# 视频任务拆分

读 项目约定（@references/project-contract.md） 与 质量规则（@references/quality.md），再读 SPEC、STATE 和已有 TICKETS。用户只要草稿/映射思路且缺原SPEC时，直接给简短草稿并标未绑定；不重建一份新SPEC来制造哈希。

## 执行

1. 核对 SPEC 批准证据和当前字节哈希。尚未批准时可以写任务草稿；不得标可执行。
2. 先找一条小而完整的路径：一个代表段落的参考 → 画面/声音 → 简易剪辑 → 可检查样片。避免先生成所有镜头才发现风格不成立。
3. 拆按需任务：复用素材、分镜/预演、单镜头、配音/音乐/音效、字幕、剪辑、QC、交付。只创建实际所需任务，不强迫所有项目经历每种工序。
4. 每项按 `templates/ticket-template.md` 写清来源、目标、依赖、不可变约束、成本状态、验收与局部失败回退。台词/字幕/源画面分离；source_mode 区分复用、确定性处理与生成。
5. 正式项目中生成 TICKETS 中唯一 JSON manifest，含 spec_sha256；JSON留在文件，聊天只展示任务摘要。校验 ID 唯一、依赖存在且无环。声音时长影响剪辑时让 edit 依赖 audio；delivery 依赖 qc；字幕依赖真实音轨/实测时轴。
6. 给出节点映射计划：Ticket ID → 逻辑节点类型/素材引用/目标结果/预期边。没有节点时 node_id 留 null。由 Implement 根据实际 Schema 翻译，不在 Ticket 固定参数名或版本号。
7. 展示任务顺序、能独立做的事项、预计生成调用与未知费用。CHECKPOINT：用户确认任务拆分后记录 tickets 哈希和证据。预算另记，任务批准不等于批准付费。
8. 交 `video-implement`。无付费批准时只标明可做的结构/离线准备，不把生成任务误列为已完成。

## 执行粒度

同一 LibTV 工程的画布写入和 revision 更新串行。独立素材分析可并行，但不能让多个执行者同时改 STATE。
当前 revision 由每次写前读取；旧 expectedRevision 不能用来恢复。
质量任务必须含完整播放，技术检查不能替代画面/声音验收。

## 失败分支

| 触发 | 第一处理 | 仍失败 |
| --- | --- | --- |
| 依赖成环 | 找实际阻挡原因，拆出参考/时长探测任务 | 标计划阻塞，不删边伪造可执行 |
| 费用未知 | 保留 unknown 与调用下限 | 只推进非计费准备 |
| 字幕接口关闭 | 任务指向已有 FFmpeg/字幕工具 | 无工具则 delivery blocked，不删字幕需求 |
| Ticket 太大 | 按可看样片/单镜头/局部编辑拆开 | 不按软件层面拆成“所有API/所有UI” |

## 禁止

不要把暂无 taskId 当任务失败；不要写死模型目录；不要自动发布 GitHub issues；不要复制四套业务预设到每个项目。
不要把“节点创建成功”当“视频交付成功”，不要让 Agent 自批预算。

## 已授权的局部修订

用户明确的局部改词按项目约定“批准继承”执行：更新受影响文件的哈希并追加revision_evidence，保留未改素材批准、原预算上限和全部消费/尝试记录。只有超出原授权范围才请求新增批准；不得仅因文件哈希变化重复询问同一修改。
