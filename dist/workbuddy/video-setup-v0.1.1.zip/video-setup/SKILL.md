---
name: video-setup
display_name: 视频环境检查
display_name_en: Video Setup
description: 检查视频创作环境、现有工程、权限、模型输入契约、计费边界和恢复记录，建立最小项目。用于开始 AI 视频项目、切换设备或会话、检查 WorkBuddy/LibTV
  连接器、确认工具能否完成分镜与局部修改。
description_zh: 检查视频创作环境、现有工程、权限、模型输入契约、计费边界和恢复记录，建立最小项目。用于开始 AI 视频项目、切换设备或会话、检查 WorkBuddy/LibTV
  连接器、确认工具能否完成分镜与局部修改。
description_en: Inspect tools, project records, capabilities and recovery readiness.
version: 0.1.1
author: 宋仕尧
---

# 视频环境检查

先读 项目约定（@references/project-contract.md） 与 LibTV 规则（@references/libtv.md）。当前工作目录不是默认视频项目；先定位用户指定项目，已有工程优先恢复。

## 执行

1. 读取已有三文件与素材引用。不存在时用 `python scripts/project_files.py init PROJECT --profile restaurant` 创建草稿；已有任何核心文件时脚本拒绝覆盖。四种 profile 见 `--help`。
2. 发现可用视频/图片/配音/素材/播放/FFmpeg 工具，核对当前连接状态、权限与必要 Schema。没有连接器仍可进入创意、规格、任务阶段，记录执行阻塞。
3. 仅对当前项目做只读探测：项目 UUID、revision.token、节点、边、时间线、issues、所需模型 inputContract。没有项目不为检测而自动创建；已获结构测试授权时用独立测试工程。
4. 在 STATE.capabilities 记录每项证据等级、范围和时间。把用户报告中的结构证据与现场结果分开；余额、报价、字幕、ASR、outputs、局部替换、恢复没有证据就写 unknown。
5. 确认素材可读取、稳定引用可恢复、音画能实际审查。探测 ffmpeg/ffprobe 只查可用性，不自动安装依赖。
6. 输出四类结果：已观察通过、仅接口/报告支持、不可用、未验证。给出可进行的下一阶段和所缺的最小证据。更新 STATE.stage=setup。

## 检查与交接

`python scripts/project_files.py check PROJECT` 检查文件与依赖；加 `--ready` 检查 SPEC/TICKETS 的实际批准和哈希及全部任务素材就绪；这是整份计划的就绪检查，不能据此阻挡只用已批准素材的当前任务。
脚本输出只代表本地记录合法，不证明平台调用和内容效果。使用技能所在绝对目录解析脚本；不要假设进程 cwd 是技能目录。
输出：三文件、当前能力证据、执行阻塞。用户已给完整创意时交 `video-to-spec`；否则交 `video-grill`。

## 失败分支

| 触发 | 第一处理 | 仍失败 |
| --- | --- | --- |
| 未连接/无权限 | 确认工具返回与目标账号/工程，记录 blocked | 保留离线创意工作；只要求恢复缺失连接，不探测其他账号 |
| projectId 可读但本地缺记录 | 回读目标工程与用户明确引用 | 不按相似名称认领客户工程 |
| Schema 与旧报告不同 | 更新能力证据，按当前契约规划 | 不凭旧字段写入 |
| 费用不可核实 | 继续非生成准备，记录费用 unknown | 暂停可能计费操作 |

## 禁止

不要以 vip:false 推断免费；不要把只用 UUID 读取成功写成严格跨会话通过；不要修改现有客户项目做烟雾测试。
不要以安装 CLI 掩盖平台缺口。只有证明必要操作缺失且 CLI 能补齐时才提出补充。


## 导入后核对

在真实WorkBuddy中读取 @references/project-contract.md 的“明确局部修改的批准继承”小节，并报告三文件名；以实际技能目录定位 scripts/project_files.py，仅先运行 --help。不能凭本正文复述冒充读到资源。按 @references/workbuddy-acceptance.md 验收；未导入、资源未读或无回执均保持未验证。
